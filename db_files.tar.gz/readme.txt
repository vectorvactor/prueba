oooooollllooc:;;;;;,,,;;;;;;;;;,,,,;,,,,,,;;;;,'.....''''';;::::::::::::::::::::::;,,,:::::'
ooooooooooooollcc:::;;;;;;;;;;;;;,,,,,,,,,,,,'.....'..',,;;:::::::::::::::::::::::,;;;:::::'
ooollllllloolllllllll:;;;;;;;;;;,,,;;;;;;;;'.........'',,;:::;,;;::::::::::::::::::::::::::'
ccllllclllllc:::::cc:;;;;;;;;;;,,;;;;;;;;;'........',''';:::,,;;,,;:::::;,,;:::::::::::::;;,
::ccc:cccc::;;;;;;;;;;;;;;;;;;,,;;;;;;;;;'........''',,:::;,;:;,;::::::;,,,:::::::::::::;,;,
;;;:;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,........'',,,;::;;;:,,:::::::;,,';:::::::::::::,;;,
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;'........,,;::::loodxddc:oolc:;,,,:::::::::::,;;,:,,
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,,,.....'.'';lodl;dOOOOOkl;dkdOOkxdolc::::::;;;,,;,;:,;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;'.'''....'';,.,cdxl,dOOOOOOc,dOdkOOxddxOOxoc::,,,,,:;,:;;:
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,',;;,..'''';c.';cod;oOOOOOOd;xOxdkl:ldxdoxOOo:::,,,:;,:;;,;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;,....''.,c,;;oxo,:kOOOOOOldOOol'ckOOOOOdko;ckkl::;,;;,;,;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;..'..'..cc:ccxOOc'oOOOOOklkOx;'lkOOOOOOOo;ckOdxdc;:;,;,;:
::::::::;;;::;;;;;;;;;;;;;;;;;;;;;'.;,..'..l:l:lkOOodxOOOOOooOOxdkOOOOOOOOk:;xOkoOOd::;;,;::
::::::::::::::::::::::::;;:::cccc:.,;,....'lcl:oOOOdkOOOOOOoxOOxkOOOOOOOOOo,dOOddOOd:;,,,::;
:::::::::::::::::::::::::codxxxxdl',;;....,ccc:dOOOdkOOOOOkokOOxOOOOOOOOOOl:kOOdkOOx:;,;::,'
c::::::::::::::::::::ccldxxkkkkxxo:::c;'..:llccoOOOxdOOOOOOokOOxkOOOOOOOOOldOOOdOOOk:,;:;'';
cc:ccc::::ccc:::cldxxxxxkkkkkxxxxxddddol,.;ooooxOkxxoxOOOOOdxOOxxOOkdddxkOdkOOOxOOOx:::;',;:
cccccccccccccccccxkkkxxxxxxxxxxddddddddodc:oooodlcxoodkOOOOkxOOkxOOdodkxocdOOOOkOOOo:;,',;;;
,;cccccc::cccccccclllodddooollooooloollllo:lool,cOK0dokOOOOOOOOOOOdx0KKKKOlxdkOOOOkc,'';,,,'
...;ccc,,cdxo;ccccccccclllcccccclccccccccc:,oo:;k00xo;oOOOOOOOOOOo:lkKKKKKo;lkOOOOd;,,,'',',
....'::,,:ol:;;....:llllllllllllllllllllllc,loc:O0ddk,cOOOOOOOOOOok;'d0KKKkcdkOOOkl;,'';,'',
  ...'';cod:;,.....:lolllllllllllllllllllll::ol:00llo;ckOOOOOOOOdok:,:OKKKO:dOOOOx:codd:,,''
 . ......':;,.. ..'loooooolloooooooooooooool:oock0o...:OOOOOOOOOl...;,xKKKO;lOOxc;dxdxOx;'',
...........','....coooooollllllooooooooooooo:co:ckk:,,cOOOOOOOOOc'..;,kKK0dcxko;,lolxOOk:,,,
.............,:...lodddolllllooooodddddddddo;:ooodxoclxOOOOOOOOOo;;,,cxkkxxOOl;oxodxokOd,,,c
..............;o'.codddolooooooooddddddddddc.'loxOOOOOOddOOOOOOOOkkxxxkOOOOOd:xOOdodkOx,;odl
...,'..........ol,looooooooooooooddxxxxxxxd,;;ldkOOOOOxdOOOOOOOOOOOOOOOOOOOx;oOkkxlxOkllxxkk
..:oc.........;ox;looooooooddooooddxxxxxxxo,l:cdkOOOOOOOOOOOOOOOOOOOOOOOOOOl;kkxooxxdodxxxxk
...............cx,cooooooodddddddddxxxxxxxd;dc:dkOOOOOkddxxxxxdkOOOOOOOOOOOooOdoooooxxxxxxxk
...............ld;cooooooddddddddddxkkkkkkxcxdccxkOOOOOOOOOOOOOOOOOOOOOOOOOOkdddocdxxxxkkkkk
..............,do;:odddodddddddddddxkkkkkkkxxxxocldkkOOOOOOOOOOOOOOOOOOOxolcldxxxlcxkxkkkkkk
.............:ddc;,ldddodddddddddddxkkkkkkkkxxxxxdlloodkOOOOOOOOOOOxoollcc''',;;:clxkxkkkkkk
;.........':oxxc.';;ldoddddddddddxxxxkkkkkkxxxxxxxxxdc,,:lodooooollclodddl'..';;;'cxkxkkxdc:
,''..';:loxkxd;...;;:odddddddddddxxxxxxxxxxxxxxxxxo:'...''..'loooddxdolc:,,;;;;;;,:xkkxc'...
lldxkkkkkkkd;.....,;,;:lddddddddddxxxxxxxxxxxdollc'.''..''..cllcc:;,',;;;;;;;;;;,;dxxo,.....
ccoxxddoc;........';;.,ldddddddxxdxxxxxxdoc:;,,,,...''......'...'',,;;;;;;;;;;,'.;lo:......'
 ..................;cldddddddddddxdlc::;;;;;;;;;;'..''''''''''''',;;;;;;;;;,,'',;',,......''
    ... ............;odddddddddlc:,,;;;;;;;;;;;;.......'''''''''';;;;;;,,''',;;;;;;;;,..'.',
      ................,:odddl:;,;;;;;;;;;;;,;;;;........'''''''''',,,,'.';;;;;;;,,,,,'...';:
      ............ ......',,,;;;;;;;;;;;,,,,;;;;'.'....'''''''.'''''''',,;;;;,''',;:::cc:;,;
      ..............,ll:'',ooc;,;;;;;;;;''';;;;;;,....'......'',,,''',;;;;;'.',:ccc:::::::;'
 .    .......,'.......'',,''okkdc:,,;;;;'.;;;;;;;;;,'..'.......'''',,,;,,',;:c:::::ccllllllc
.....,::cldxkOx,.....,;;;;;,,;lkkkxoc;,;'';:,,,;;;;;;;'..'''.'',;;;,,,,;:lc::::clllllcccclll
....'dOOOOOOOOOd'...',;;;;;;;;,;:okOOkdl;.ox;,,;,,,;;;;,'....',,,,;:ccc::::ccllllclc::clllll
.....oOOOOOOOOOOo...',:;,;;;;;;;;,;cdkOOkdool..cl:..:c::cc:;,;;::::::::cccllclclcc;;clllllll
.....okOOOOOOOOOO;..'loo;,;;;;;;;;,''coxOOOd:;,cl, .l':d:;::;;::;;:cccccllllcc:cc;;cccllllll


Hola Goku y compañia! necesito vuestra ayuda para encontrar las bolas de dragón,
pues sé de buena tinta que se han esparcido por distintas localidades de
Cantabria.

En tu ordenador están los archivos de registro del radar que inventé para
localizar las bolas, ahí debería estar la información acerca de dónde se 
encuentran los archivos que contienen las coordenadas exactas y una imagen que nos da 
más pistas del lugar exacto donde cayeron tras invocar a Shenron.

Sólo dispones de la terminal de Linux para encontrar esos archivos. Por cada una
de las bolas que encontréis, Víctor os otorgará MiBs en función de cuándo lo hayáis 
hecho respecto al resto de equipos:
    
    - 1º: 50 MiB
    - 2º: 30 MiB
    - 3º: 20 MiB
    - 4º y 5º: 10 MiB    
    
Si además toda la clase conseguís encontrarlas, os otorgará 100 MiB extras a cada equipo.

¡Suerte!


Bulma.




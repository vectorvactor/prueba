

Hola Goku y compañia! necesito vuestra ayuda para encontrar las bolas de dragón,
pues sé de buena tinta que se han esparcido por distintas localidades de
Cantabria.

En tu ordenador están los archivos de registro del radar que inventé para
localizar las bolas, ahí debería estar la información acerca de dónde se 
encuentran los archivos con las coordenadas exactas y una imagen que nos da 
más pistas del lugar exacto donde cayeron tras invocar a Shenron.

Sólo dispones de la terminal de Linux para encontrar esos archivos. Por cada una
de las bolas que encuentres, Víctor te otorgará 50 MiB. Si además toda la clase
conseguís encontrarlas, os otorgará 100 MiB extras a cada equipo.

¡Suerte!


Bulma.
